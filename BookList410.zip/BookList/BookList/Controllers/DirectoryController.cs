﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace BookList.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DirectoryController : ControllerBase
    {
        List<string> dList = new List<string>();

        [HttpGet]
        public List<string> getFile()
        {
            return Directory.GetFiles("./").ToList();
        }
    }
}