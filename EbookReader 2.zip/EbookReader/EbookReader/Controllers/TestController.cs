
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace EbookReader.Controllers
{
    public class TestController : Controller
    {

        [Authorize(Roles = "Administrator")]
        public IActionResult RequireAdministratorRole()
        {
            ViewData["role"] = "Administrator";
            return View("Test");
        }

        [Authorize(Roles = "User")]
        public IActionResult RequireUserRole()
        {
            ViewData["role"] = "User";
            return View("Test");
        }

        [Authorize(Policy = "RequireAdministratorRole")]
        public IActionResult PolicyExample()
        {
            ViewData["role"] = "Administrator";
            return View("Test");
        }
    }
}