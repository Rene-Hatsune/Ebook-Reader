﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Extensions;
using EbookReader.Models;
using EbookReader.Data;

namespace EbookReader.Controllers
{
    public class HomeController : Controller
    {

        private readonly ApplicationDbContext Context_;

        private const string sessionId_ = "SessionId";

        public HomeController(ApplicationDbContext context)

        {
            Context_ = context;
        }

        //-------------------------<Index>------------------------
        public IActionResult Index()
        {
            return View(Context_.Books.ToList<Book>());
        }

        //---------------show a list of authors, order by lastName
        public IActionResult AuthorDetails()
        {
            var auths = Context_.Authors.Include(a => a.Book);
            var orderedAuths = auths.OrderBy(a => a.lastName)
              .OrderBy(a => a.Book)
              .Select(a => a);

            return View(orderedAuths);
        }

        //----< displays form for creating a book >----------------

        [HttpGet]
        public IActionResult CreateBook(int id)

        {
            var model = new Book();
            return View(model);
        }

        //----< posts back new books details >---------------------

        [HttpPost]
        public IActionResult CreateBook(int id, Book bks)

        {
            Context_.Books.Add(bks);
            Context_.SaveChanges();
            return RedirectToAction("Index");
        }

        //----< deletes a book by id >-----------------------------
        [Authorize(Roles = "Administrator")]
        public IActionResult DeleteBook(int? id)

        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            try
            {
                var book = Context_.Books.Find(id);

                if (book != null)
                {
                    Context_.Remove(book);
                    Context_.SaveChanges();
                }
                if (book == null)
                {
                    return StatusCode(StatusCodes.Status400BadRequest);
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            return RedirectToAction("Index");
        }

        //----< shows details for each book >----------------------

        public ActionResult BookDetails(int? id)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            Book book = Context_.Books.Find(id);

            if (book == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            var auths = Context_.Authors.Where(a => a.Book == book);

            book.Authors = auths.OrderBy(a => a.lastName).Select(a => a).ToList<Author>();
            // book.Authors = auths.ToList<Author>();

            if (book.Authors == null)
            {
                book.Authors = new List<Author>();
                Author auth = new Author();
                auth.firstName = "none";
                auth.lastName = "none";
                auth.isPrimaryAuthor = "none";
                book.Authors.Add(auth);
            }
            return View(book);
        }
        //----< gets form to edit a specific book via id >---------
        [HttpGet]
        public IActionResult EditBook(int? id)
        {
            if (id == null)
            {
                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest);
            }
            Book book = Context_.Books.Find(id);
            if (book == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            return View(book);
        }

        //----< posts back edited results for specific book >------
        [HttpPost]
        public IActionResult EditBook(int? id, Book bks)

        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            var book = Context_.Books.Find(id);
            if (book != null)
            {
                book.name = bks.name;
                book.genre = bks.genre;
                try
                {
                    Context_.SaveChanges();
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status400BadRequest);
                }
            }
            return RedirectToAction("Index");
        }

        //----< shows form for creating a author >------------------
        [HttpGet]
        public IActionResult CreateAuthor(int id)
        {
            var model = new Author();
            return View(model);
        }

        //----< posts back new authors details >---------------------

        [HttpPost]
        public IActionResult CreateAuthor(int id, Author auth)

        {
            Context_.Authors.Add(auth);
            Context_.SaveChanges();
            return RedirectToAction("Authors");
        }

        //----< add new author to book >--------------------------

        [HttpGet]
        public IActionResult AddAuthor(int id)
        {
            HttpContext.Session.SetInt32(sessionId_, id);
            // TempData[sessionId_] = id;
            Book book = Context_.Books.Find(id);

            if (book == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            Author auth = new Author();
            return View(auth);
        }

        //----< add new author to book >--------------------------

        [HttpPost]
        public IActionResult AddAuthor(int? id, Author auth)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            // retreive the target book from static field
            int? bookId_ = HttpContext.Session.GetInt32(sessionId_);
            // int bookId_ = (int)TempData[sessionId_];
            var book = Context_.Books.Find(bookId_);
            if (book != null)
            {
                if (book.Authors == null)  // doesn't have any authors yet
                {
                    List<Author> authors = new List<Author>();
                    book.Authors = authors;
                }
                book.Authors.Add(auth);
                try
                {
                    Context_.SaveChanges();
                }
                catch (Exception)
                {
                }
            }
            return RedirectToAction("Index");

        }

        //----< gets form to edit a specific author via id >---------

        [HttpGet]
        public IActionResult EditAuthor(int? id)
        {
            if (id == null)
            {
                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest);
            }
            Author author = Context_.Authors.Find(id);
            if (author == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            return View(author);
        }

        //----< posts back edited results for specific author >------
        [HttpPost]
        public IActionResult EditAuthor(int? id, Author auth)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }

            var author = Context_.Authors.Find(id);
            if (author != null)
            {

                author.lastName = auth.lastName;
                author.firstName = auth.firstName;
                try
                {
                    Context_.SaveChanges();
                }
                catch (Exception)
                {
                }

            }
            return RedirectToAction("Index");
        }

        //----< deletes a author by id >-----------------------------

        public IActionResult DeleteAuthor(int? id)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            try
            {
                var author = Context_.Authors.Find(id);
                if (author != null)
                {
                    Context_.Remove(author);
                    Context_.SaveChanges();
                }
            }
            catch (Exception)
            {
            }
            return RedirectToAction("Index");
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
