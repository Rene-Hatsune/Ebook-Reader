﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace EBookReader.Models
{
    public class Topic
    {
        public int TopicID { get; set; }
        public IList<TopicBook> TopicBooks { get; set; }
        [Required]
        [StringLength(30)]
        public string TopicName { get; set; }
        [StringLength(100)]
        public string TopicDescription { get; set; }
    }
}
