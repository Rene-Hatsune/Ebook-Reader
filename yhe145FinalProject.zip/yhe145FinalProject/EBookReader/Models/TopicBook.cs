﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EBookReader.Models
{
    public class TopicBook
    {
        public int BookID { get; set; }
        public Book Book { get; set; }
        public int TopicID { get; set; }
        public Topic Topic { get; set; }
    }
}
