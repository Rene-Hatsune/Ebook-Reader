﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;

namespace EBookReader.Models
{
    public class Author
    {
        public int AuthorID { get; set; }
        [Required]
        public string AuthorName { get; set; }
        public string AuthorDescription { get; set; }
        public IList<AuthorBook> AuthorBooks { get; set; }
    }
}
