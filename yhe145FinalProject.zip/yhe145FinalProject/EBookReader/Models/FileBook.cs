﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.ComponentModel;
using System.IO;
using System.Net.Http.Headers;

namespace EBookReader.Models
{
    public class FileInput
    {
        public IFormFile UploadFile { get; set; }
    }
    public class FileBook
    {
        public Book Book { get; set; }
        public FileInput FileInput { get; set; }
    }

}
