﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EBookReader.Models
{
    public class Publisher
    {
        public int PublisherID { get; set;}
        [Required]
        [StringLength(100)]
        public string PublisherName { get; set;}
        public ICollection<Book> Books { get; set; }
    }
}
