﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;    
using System.ComponentModel.DataAnnotations; 
using Microsoft.AspNetCore.Mvc;

namespace EBookReader.Models
{
    public class Book
    {
        public int BookID { get; set; }
        [Required]
        public string BookTitle { get; set; }
        [Required]
        public string Section { get; set; }
        public string Description { get; set; }
        public int? PublisherID { get; set; }
        public Publisher Publisher { get; set; }
        public string UserUploaded { get; set; }
        public IList<AuthorBook> AuthorBooks { get; set; }
        public string Path { get; set; }
        public string FileName { get; set; }
        public string FileExtension { get; set; }
        public IList<TopicBook> TopicBooks { get; set; }
        public IList<UserBook> UserBooks { get; set; }
        public ICollection<Comment> Comments { get; set; }
    }
}
