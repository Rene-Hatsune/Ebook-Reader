﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;    
using System.ComponentModel.DataAnnotations;

namespace EBookReader.Models
{
    public class Comment
    {
        public int CommentID { get; set; }
        [DisplayName("Comments")]
        [StringLength(100)]
        public string CommentContent { get; set; }
        public string UserName { get; set; }
        public int? BookID { get; set; }
        public Book Book { get; set; }
    }
}
