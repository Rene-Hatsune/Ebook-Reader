﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Extensions;
using EBookReader.Data;
using EBookReader.Models;
using Microsoft.AspNetCore.Authorization;

namespace EBookReader.Controllers
{
    public class AuthorController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly string sessionID_ = "SessionId"; 

        public AuthorController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Author
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            return View(await _context.Authors.ToListAsync());
        }

        // GET: Author/Details/5
        [AllowAnonymous]
        public IActionResult AuthorDetails(int? id)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }

            Author author = _context.Authors.Find(id);
            if (author == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            var authorBooks = _context.AuthorBooks.Where(ab => ab.Author == author);
            author.AuthorBooks = authorBooks.OrderBy(authorBook => authorBook.Book.BookTitle)
                .Select(authorBook => authorBook).ToList<AuthorBook>();

            var books = _context.Books;
            foreach (var ab in author.AuthorBooks)
            {
                ab.Book = books.Find(ab.BookID);
            }

            return View(author);
        }

        // GET: Author/Create
        [HttpGet]
        [Authorize]
        public IActionResult CreateAuthor(int id)
        {
            var author = new Author();
            return View(author);
        }

        // POST: Author/Create
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public IActionResult CreateAuthor(int? id, Author author)
        {
            if (ModelState.IsValid)
            {
                _context.Add(author);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return RedirectToAction("Index");
        }

        // GET: Author/Edit/5
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult EditAuthor(int? id)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }

            Author author =  _context.Authors.Find(id);
            if (author == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            return View(author);
        }

        // POST: Author/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public IActionResult EditAuthor(int? id, Author author)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            Author au = _context.Authors.Find(id);
            if (au != null)
            {
                au.AuthorName = author.AuthorName;
                au.AuthorDescription = author.AuthorDescription;
            }
            if (ModelState.IsValid)
            {
                try
                {
                    //_context.Update(author);
                    _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AuthorExists(author.AuthorID))
                    {
                        return StatusCode(StatusCodes.Status404NotFound);
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(author);
        }

        // GET: Author/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteAuthor(int? id)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }

            var author = await _context.Authors
                .FirstOrDefaultAsync(m => m.AuthorID == id);
            if (author == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }

            return View(author);
        }

        // POST: Author/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            var author = await _context.Authors.FindAsync(id);
            _context.Authors.Remove(author);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AuthorExists(int id)
        {
            return _context.Authors.Any(e => e.AuthorID == id);
        }

        [HttpGet]
        [Authorize]
        public IActionResult AddBook (int id)
        {
            HttpContext.Session.SetInt32(sessionID_, id);
            var author = _context.Authors.Find(id);
            if(author == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            AuthorBook authorBook = new AuthorBook();
            List<Book> BookList = _context.Books.ToList<Book>();
            ViewBag.authorbook = authorBook;
            ViewBag.bookList = BookList;
            return View();
        }

        [HttpPost]
        [Authorize]
        public IActionResult AddBook(int? id, AuthorBook authorBook)
        {
            int? authorID = HttpContext.Session.GetInt32(sessionID_);
            if(id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            int SelectValue = authorBook.BookID;
            ViewBag.SelectValue = authorBook.BookID;
            

            var author = _context.Authors.Find(authorID);
            if (author != null)
            {
                if (author.AuthorBooks == null)
                {
                    author.AuthorBooks = new List<AuthorBook>();
                }
                authorBook.Author = author;
                authorBook.AuthorID = author.AuthorID;

                var book = _context.Books.Find(authorBook.BookID);
                if(book == null)
                {
                    book.AuthorBooks = new List<AuthorBook>();
                }
                List<AuthorBook> abList = _context.AuthorBooks.ToList<AuthorBook>();
                foreach (AuthorBook ab in abList)
                {
                    if ((ab.AuthorID == authorBook.AuthorID) && (ab.BookID == authorBook.BookID))
                    {
                        _context.SaveChanges();
                        List<Author> authorList = _context.Authors.ToList<Author>();
                        return View("Index", authorList);
                    }
                }
                authorBook.Book = book;
                authorBook.BookID = book.BookID;
                //book.AuthorBooks.Add(authorBook);
                author.AuthorBooks.Add(authorBook);
                _context.SaveChanges();
            }
            List<Author> alist = _context.Authors.ToList<Author>();
            return View("Index", alist);
        }
    }
}
