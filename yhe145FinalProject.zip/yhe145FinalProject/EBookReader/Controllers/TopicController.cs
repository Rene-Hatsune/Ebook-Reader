﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Extensions;
using EBookReader.Data;
using EBookReader.Models;
using Microsoft.AspNetCore.Authorization;

namespace EBookReader.Controllers
{
    public class TopicController : Controller
    {
        private readonly ApplicationDbContext _context;

        private readonly string sessionId_ = "SessionId";

        public TopicController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Topic
        public async Task<IActionResult> Index()
        {
            return View(await _context.Topics.ToListAsync());
        }

        // GET: Topic/Details/5
        public IActionResult TopicDetails(int? id)
        {
            Topic topic = _context.Topics.Find(id); 
            if (id == null)
            {
                return BadRequest();
            }

            
            if (topic == null)
            {
                return NotFound();
            }
            var topicBook = _context.TopicBooks.Where(tb => tb.Topic == topic);
            topic.TopicBooks = topicBook.Select(tb => tb).ToList<TopicBook>();
            var books = _context.Books;
            foreach (var tb in topic.TopicBooks)
            {
                tb.Book = books.Find(tb.BookID);
            }

            return View(topic);
        }

        // GET: Topic/Create
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult CreateTopic()
        {
            var model = new Topic();
            return View(model);
        }

        // POST: Topic/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateTopic([Bind("TopicID,TopicName,TopicDescription")] Topic topic)
        {
            if (ModelState.IsValid)
            {
                _context.Add(topic);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(topic);
        }


        // GET: Topic/Edit/5
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> EditTopic(int? id)
        {
            if (id == null)
            {
                return BadRequest() ;
            }
            var topic = await _context.Topics.FindAsync(id);
            if (topic == null)
            {
                return NotFound();
            }
            return View(topic);
        }

        // POST: Topic/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> EditTopic(int? id, Topic topic)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var tp = _context.Topics.Find(id);
            if (tp != null)
            {
                tp.TopicName = topic.TopicName;
                tp.TopicDescription = topic.TopicDescription;
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TopicExists(topic.TopicID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(topic);
        }

        // GET: Topic/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteTopic(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            try
            {
                var topic = await _context.Topics
                    .FirstOrDefaultAsync(m => m.TopicID == id);
                if (topic != null)
                {
                    _context.Remove(topic);
                    _context.SaveChanges();
                }
            }
            catch(Exception)
            {
                Console.WriteLine("Error. Topic not deleted.");
            }
            return RedirectToAction("Index");
        }

        private bool TopicExists(int id)
        {
            return _context.Topics.Any(e => e.TopicID == id);
        }
    }
}
