﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Extensions;
using EBookReader.Models;
using EBookReader.Data;
using System.Web;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace EBookReader.Controllers
{
    public class BookController : Controller
    {
        private readonly ApplicationDbContext _context;

        private readonly string sessionId_ = "SessionId";

        private readonly IHostingEnvironment hostingEnvironment_;
        private string webRootPath_ = null;
        private string filePath_ = null;
        
        private string run;

        public BookController(ApplicationDbContext context, IHostingEnvironment hostingEnvironment)
        {
            hostingEnvironment_ = hostingEnvironment;
            webRootPath_ = hostingEnvironment.WebRootPath;
            filePath_ = Path.Combine(webRootPath_, "FileStorage");
            _context = context;
        }

        // GET: Book
        public IActionResult Index()
        {
            if (HttpContext.User.IsInRole("Admin"))
            {
                var BookList = from book in _context.Books
                               select book;
                return View(BookList.ToList<Book>());
            }
            else
            {
                var BookList = from book in _context.Books
                               where (book.UserUploaded == HttpContext.User.Identity.Name) || book.Section == "Public"
                               select book;
                return View(BookList.ToList<Book>());
            }
        }

        // GET: Book/Details/5
        public async Task<IActionResult> BookDetails(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }

            var book = await _context.Books
                .Include(b => b.Publisher)
                .FirstOrDefaultAsync(m => m.BookID == id);
            if (book == null)
            {
                return NotFound();
            }

            Publisher publisher = _context.Publishers.Find(book.PublisherID);
            if (publisher != null)
            {
                book.PublisherID = publisher.PublisherID;
            }

            var authorBooks = _context.AuthorBooks.Where(ab => ab.Book == book);
            book.AuthorBooks = authorBooks.ToList<AuthorBook>();
            var authors = _context.Authors;

            foreach (var ab in book.AuthorBooks)
            {
                ab.Author = authors.Find(ab.AuthorID);
            }

            var topicBooks = _context.TopicBooks.Where(tb => tb.Book == book);
            book.TopicBooks = topicBooks.ToList<TopicBook>();
            var topics = _context.Topics;

            foreach (var tb in book.TopicBooks)
            {
                tb.Topic = topics.Find(tb.TopicID);
            }
            return View(book);
        }

        // GET: Book/Create
        [HttpGet]
        [Authorize]
        public IActionResult CreateBook(int id)
        {
            var model = new FileBook();
            return View(model);
        }

        // POST: Book/Create
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateBook(int id, FileBook model)
        {
            if (model == null ||model.FileInput.FileUpload == null)
            {
                return Content("File is null");
            }

            var fpath = Path.Combine(filePath_,model.FileInput.FileUpload.Filename);

            model.Book.FileName = model.FileInput.FileUpload.Filename;
            model.Book.FileExtension = Path.GetExtension(fpath);
            model.Book.UserUploaded =  HttpContext.User.Identity.Name;

            using (var stream = new FileStream(fpath, FileMode.Create))
            {
                await model.FileInput.FileUpload.CopyToAsync(stream);
            }

            if (ModelState.IsValid)
            {
                _context.Add(model.Book);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: Book/Edit/5
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult EditBook(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Book book = _context.Books.Find(id);
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        // POST: Book/Edit/5
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public IActionResult EditBook(int? id, Book book)
        {
            
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            var bk = _context.Books.Find(id);
            if (bk != null)
            {
                bk.Section = book.Section;
                bk.BookTitle = book.BookTitle;
                bk.Description = book.Description;
                bk.PublisherID = book.PublisherID;
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    Console.WriteLine("Save change failed");
                    if (!BookExists(book.BookID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            return RedirectToAction("Index");
        }

        // GET: Book/Delete/5
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteBook(int? id)
        {
            try
            {
                if (id == null)
                {
                    return BadRequest();
                }
                var book = _context.Books.Find(id);
                if (book != null)
                {
                    var comment = _context.Comments.Where(c => c.BookID == book.BookID);
                    foreach (Comment c in comment.ToList())
                    _context.Comments.Remove(c);
                    _context.Remove(book);
                    _context.SaveChanges();
                }

            }
            catch (Exception)
            {
                Console.WriteLine("Book is null");
            }
            return RedirectToAction("Index");
        }
        

        private bool BookExists(int id)
        {
            return _context.Books.Any(e => e.BookID == id);
        }

        [HttpGet]
        [Authorize]
        public IActionResult AddAuthor(int id)
        {
            HttpContext.Session.SetInt32(sessionId_, id);
            Book book = _context.Books.Find(id);
            if (book == null)
            {
                return NotFound();
            }
            AuthorBook Authorbook = new AuthorBook();
            List<Author> AuthorList = _context.Authors.ToList();
            ViewBag.authorBook = Authorbook;
            ViewBag.authorList = AuthorList;
            return View();
        }
        [HttpGet]
        [Authorize]
        public IActionResult AddTopic(int id)
        {
            HttpContext.Session.SetInt32(sessionId_, id);
            Book book = _context.Books.Find(id);
            if (book == null)
            {
                return NotFound();
            }
            TopicBook topicBook = new TopicBook();
            List<Topic> topicList = _context.Topics.ToList();
            ViewBag.Topicbook = topicBook;
            ViewBag.topicList = topicList;
            return View();
        }


        [HttpPost]
        [Authorize]
        public IActionResult AddAuthor(int? id, AuthorBook authorBook)
        {
            int? bookId = HttpContext.Session.GetInt32(sessionId_);
            try
            {
                if (id == null)
                {
                    return BadRequest();
                }
                int SelectedValue = authorBook.AuthorID;
                ViewBag.SelectedValue = authorBook.AuthorID;
                
                var book = _context.Books.Find(bookId);
                var author = _context.Authors.Find(authorBook.AuthorID);
                List<AuthorBook> Listab = _context.AuthorBooks.ToList<AuthorBook>();
                if (book != null)
                {
                    if (book.AuthorBooks == null)
                    {
                        book.AuthorBooks = new List<AuthorBook>();
                    }
                    authorBook.Book = book;
                    authorBook.BookID = book.BookID;
                    if (author == null)
                    {
                        return NotFound();
                    }
                    if (author.AuthorBooks == null)
                    {
                        author.AuthorBooks = new List<AuthorBook>();
                    }
                    foreach (AuthorBook ab in Listab)
                    {
                        if (ab.AuthorID == authorBook.AuthorID && ab.BookID == authorBook.BookID)
                        {
                            _context.SaveChanges();
                           
                            List<Book> ListOfBook = _context.Books.ToList();
                            return View("Index", ListOfBook);
                        }
                    }
                    authorBook.Author = author;
                    authorBook.AuthorID = author.AuthorID;
                    author.AuthorBooks.Add(authorBook);
                    book.AuthorBooks.Add(authorBook);

                    _context.SaveChanges();

                }
                List<Book> bookList = _context.Books.ToList();
            }
            catch(Exception){
                Console.WriteLine("Error while adding an author.");
            }
            return View("Index", bookList);
        }
        [HttpPost]
        [Authorize]
        public IActionResult AddTopic(int? id, TopicBook topicBook)
        {
            int? bookId = HttpContext.Session.GetInt32(sessionId_);
            var book = _context.Books.Find(bookId);
            var topic = _context.Topics.Find(topicBook.TopicID);
            List<TopicBook> Listtb = _context.TopicBooks.ToList();
            if (id == null)
            {
                return BadRequest();
            }
            int SelectedValue = topicBook.TopicID;
            ViewBag.SelectedValue = topicBook.TopicID;
            
            if (book != null)
            {
                if (book.TopicBooks == null)
                {
                    book.TopicBooks = new List<TopicBook>();
                }
                topicBook.Book = book;
                topicBook.BookID = book.BookID;
                
                if (topic == null)
                {
                    return StatusCode(StatusCodes.Status404NotFound);
                }
                if (topic.TopicBooks == null)
                {
                    topic.TopicBooks = new List<TopicBook>();
                }
                
                foreach (TopicBook tb in Listtb)
                {
                    if (tb.BookID == topicBook.BookID && tb.TopicID == topicBook.TopicID)
                    { 
                        _context.SaveChanges();
                        
                        List<Book> books = _context.Books.ToList();

                        return View("Index", books);
                    }
                }
                topicBook.Topic = topic;
                topicBook.TopicID = topic.TopicID;
                topic.TopicBooks.Add(topicBook);
                book.TopicBooks.Add(topicBook);


                _context.SaveChanges();
            }
            List<Book> bookList = _context.Books.ToList();
            return View("Index", bookList);
        }

        [HttpGet]
        [Authorize]
        public IActionResult AssignPublisher(int id)
        {
            HttpContext.Session.SetInt32(sessionId_, id);
            var book = _context.Books.Find(id);
            Publisher publisher = new Publisher();
            
            if (book == null)
            {
                return NotFound();
            }
            List<Publisher> publishers = _context.Publishers.ToList();
            
            ViewBag.publisher = publisher;
            ViewBag.publisherList = publishers;
            return View();
        }

        [HttpPost]
        [Authorize]
        public IActionResult AssignPublisher(int? id, Publisher publisher)
        {
            int? bookId = HttpContext.Session.GetInt32(sessionId_);
            var book = _context.Books.Find(bookId);
            var pbl = _context.Publishers.Find(publisher.PublisherID);
            if (id == null)
            {
                return BadRequest();
            }
            
            if (book == null)
            {
                return NotFound();
            }
            
            if (pbl == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }

            var books = _context.Books.Where(bk => bk.Publisher == pbl);
            pbl.Books = books.ToList();
            foreach (Book bk in pbl.Books)
            {
                if (bk.BookTitle == book.BookTitle && bk.Description == book.Description)
                {
                    return RedirectToAction("Index");
                }
            }
            pbl.Books.Add(book);
            book.Publisher = pbl;


            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        // Book View
        public ActionResult ReadBook(int? id)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }

            Book book = _context.Books.Find(id);
            if (book == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }

            UserBook ubs = new UserBook();
            ubs.Book = book;
            var cmts = _context.Comments.Include(l => l.Book);
            var orderedComs = cmts.Where(l => l.BookID == book.BookID);
            ubs.Comments = orderedComs;

            return View(ubs);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Comment(int id)
        {
            UserBook ubs = new UserBook();
            Book book = _context.Books.Find(id);

            var cmts = _context.Comments.Include(l => l.Book);
            var orderedComs = cmts.Where(l => l.BookID == book.BookID);
            ubs.Comments = orderedComs;
            ubs.Book = book;
            return View(ubs);
        }

        [HttpGet]
        [Authorize]
        public IActionResult CommentAdd(int id)
        {
           
            Book book = _context.Books.Find(id);
            if (book == null)
            {
                return NotFound();
            }
            Comment cmt = new Comment();
            cmt.BookID = book.BookID;
            return View(cmt);
        }

        [HttpPost]
        [Authorize]
        public IActionResult CommentAdd(int? id, Comment cmt)
        {
            int? bookId_ = HttpContext.Session.GetInt32(sessionId_);
            if (id == null)
            {
                return BadRequest();
            }

            cmt.UserName = HttpContext.User.Identity.Name;
            var bk = _context.Books.Find(bookId_);

            if (bk != null)
            {
                if (bk.Comments == null)
                {
                    List<Comment> comments = new List<Comment>();
                    bk.Comments = comments;
                }
                bk.Comments.Add(cmt);

                try
                {
                    _context.SaveChanges();
                }
                catch (Exception)
                {
                    Console.WriteLine("No comments.");
                }
            }
            return RedirectToAction("ReadBook", new { id = bookId_ });

        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult CommentEdit(int? id)
        {
            if (id == null)
            {
                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest);
            }
            Comment cmt = _context.Comments.Find(id);

            if (cmt == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            return View(cmt);
        }

       
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult CommentEdit(int? id, Comment cmt)
        {
            var comment = _context.Comments.Find(id);

            try
            {
                if (id == null)
                {
                    return StatusCode(StatusCodes.Status400BadRequest);
                }

                if (comment != null)
                {
                    comment.CommentContent = cmt.CommentContent;
                    _context.SaveChanges();
                }
            }
            catch (Exception)
            {
                 Console.WriteLine("Error. This comment could not be edited.");
                
            }
            return RedirectToAction("Comment", new { id = comment.BookID });
        }


        //Delete comment by id 
        [Authorize(Roles = "Admin")]
        public IActionResult CommentDelete(int? id)
        {
            var comment = new Comment();
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            try
            {
                comment = _context.Comments.Find(id);
                if (comment != null)
                {
                    _context.Remove(comment);
                    _context.SaveChanges();
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error. Comment not delete.");
            }
            return RedirectToAction("Comment", new { id = comment.BookID });
        }
    }
}
