﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Extensions;
using EBookReader.Models;
using EBookReader.Data;
using Microsoft.AspNetCore.Authorization;

namespace EBookReaderProject.Controllers
{
    public class PublisherController : Controller
    {
        private readonly ApplicationDbContext context_;
        private readonly string sessionId_ = "SessionId";

        public PublisherController(ApplicationDbContext context)
        {
            context_ = context;
        }

        public IActionResult Index()
        {
            var model = context_.Publishers.ToList();
            return View(model);
        }

        public ActionResult Details(int? id)
        {
             Publisher pb = context_.Publishers.Find(id);
            try {
                if (id == null)
            {
                return BadRequest();
            }
           
            if (pb == null)
            {
                return NotFound();
            }
            var books = context_.Books.Where(book => book.Publisher == pb);
            pb.Books = books.ToList<Book>();
            if (pb.Books == null)
            {
                pb.Books = new List<Book>();
                Book bk = new Book();
                bk.BookTitle = "None";
                bk.Description = "None";
                pb.Books.Add(bk);
            }
            }
            catch(Exception){
                Console.WriteLine("Error. No details were found.");
            }
            return View(pb);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult AddNewBook(int id)
        {
            HttpContext.Session.SetInt32(sessionId_, id);
            Publisher pub = context_.Publishers.Find(id);
            if (pub == null)
            {
                return NotFound();
            }
            Book bk = new Book();
            return View(bk);

        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult AddNewBook(int? id, Book bk)
        {
            int? publisherId = HttpContext.Session.GetInt32(sessionId_);
            try{
                 if (id == null)
                {
                    return BadRequest();
                }

                var publisher = context_.Publishers.Find(publisherId);
                if (publisher != null)
                {
                    if (publisher.Books == null)
                    {
                        List<Book> books = new List<Book>();
                        publisher.Books = books;
                    }
                    publisher.Books.Add(bk);
                    context_.SaveChanges();

                }
            }
            catch(Exception){
                Console.WriteLine("Error. No new book was added.");
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult EditPublisher(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Publisher pub = context_.Publishers.Find(id);
            if (pub == null)
            {
                return NotFound();

            }
            return View(pub);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult EditPublisher(int? id, Publisher pub)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var publisher = context_.Publishers.Find(id);
            if (publisher != null)
            {
                publisher.PublisherID = pub.PublisherID;
            }
            try
            {
                context_.SaveChanges();
            }
            catch (Exception)
            {

            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult CreatePublisher(int id)
        {
            var model = new Publisher();
            return View(model);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult CreatePublisher(int id, Publisher pub)
        {
            context_.Publishers.Add(pub);
            context_.SaveChanges();
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult DeletePublisher(int? id)
        {
            if (id == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            try
            {
                var pub = context_.Publishers.Find(id);
                if (pub != null)
                {
                    context_.Remove(pub);
                    context_.SaveChanges();
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Delete Error.");
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        [Authorize]
        public IActionResult AddBook(int id)
        {
            HttpContext.Session.SetInt32(sessionId_, id);
            var publisher = context_.Publishers.Find(id);
            if (publisher == null)
            {
                return NotFound();
            }
            
            var books = context_.Books.ToList();
            var book = new Book();
            ViewBag.book = book;
            ViewBag.bookList = books;
            return View();
        }

        [HttpPost]
        [Authorize]
        public IActionResult AddBook(int? id, Book book)
        {
            int? publisherId = HttpContext.Session.GetInt32(sessionId_);
            if (id == null)
            {
                return BadRequest();
            }
            var publisher = context_.Publishers.Find(publisherId);
            if (publisher == null)
            {
                return StatusCode(StatusCodes.Status404NotFound);
            }
            var books = context_.Books.Where(bk => bk.Publisher == publisher);
            publisher.Books = books.Select(bk => bk).ToList();
            foreach (var bk in publisher.Books)
            {
                if (bk.BookID == book.BookID)
                {
                    return RedirectToAction("Index");
                }
            }
            book = context_.Books.Find(book.BookID);
            publisher.Books.Add(book);
            book.Publisher = publisher;
            context_.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}