﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.IO;
using EBookReader.Models;
using EBookReader.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace EBookReader.Controllers
{

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class FilesController : ControllerBase
    {
        private readonly IHostingEnvironment hostingEnvironment_;
        private string webRootPath_ = null;
        private string filePath_ = null;
        private readonly ApplicationDbContext context_;

        public FilesController(IHostingEnvironment hostingEnvironment, ApplicationDbContext dbContext)
        {
            hostingEnvironment_ = hostingEnvironment;
            webRootPath_ = hostingEnvironment.WebRootPath;
            filePath_ = Path.Combine(webRootPath_, "FileStorage");
            context_ = dbContext;
        }

        private string GetContentType(string path)
        {
            var types = GetMimeTypes();
            var ext = Path.GetExtension(path).ToLowerInvariant();
            return types[ext];
        }

        private Dictionary<string, string> GetMimeTypes()
        {
            return new Dictionary<string, string>
            {
                {".cs", "application/C#" },
                {".txt", "text/plain"},
                {".pdf", "application/pdf"}
            };
        }

        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            List<string> files = null;
            try
            {
                files = Directory.GetFiles(filePath_).ToList();
                for (int i = 0; i < files.Count; ++i)
                    files[i] = Path.GetFileName(files[i]);
            }
            catch
            {
                files = new List<string>();
                files.Add("404 - Not Found");
            }
            return files;
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Download(int id)
        {
            List<string> files = null;
            string file = "";
            try
            {
                files = Directory.GetFiles(filePath_).ToList<string>();
                if (0 <= id && id < files.Count){
                     file = Path.GetFileName(files[id]);
                }
                   
                else{
                    return NotFound();
                }
                    
            }
            catch(Exception)
            {
                return NotFound();
            }
            var memory = new MemoryStream();
            file = files[id];
            using (var stream = new FileStream(file, FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            return File(memory, GetContentType(file), Path.GetFileName(file));

        }

        // POST api/<controller>
        [HttpPost]
        public async Task<IActionResult> Upload()
        {
            try
            {
                var request = HttpContext.Request;
                var file = request.Form.Files[0];
                if (file == null || file.Length <= 0)
                {
                    return BadRequest();
                }
                foreach (var f in request.Form.Files)
                {
                    if (f.Length > 0)
                    {
                        var path = Path.Combine(filePath_, f.FileName);
                        using (var fileStream = new FileStream(path, FileMode.Create))
                        {
                            await f.CopyToAsync(fileStream);
                        }
                    }
                }
             
            }
            catch (FileNotFoundException)
            {
                return BadRequest();
            }
            return Ok();
        }



        // PUT api/<controller>/5
        //According to the HTTP specification, a PUT request 
        //requires the client to send the entire updated entity, not just the changes.
        

        //Delete api/Files/id
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
            string result = "";
            List<string> files = null;
            files = Directory.GetFiles(filePath_).ToList<string>();
            try
            {
                if (0 > id || id >= files.Count)
                {
                    result = "File not found";
                    return result;
                }
            }
            catch (FieldAccessException)
            {
                result = "Error.";
                return result;
            }
            System.IO.File.Delete(files[id]);
            return "File Delete";
        }
    }
}
