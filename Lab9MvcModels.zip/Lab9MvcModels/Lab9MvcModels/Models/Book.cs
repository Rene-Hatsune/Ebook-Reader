﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab9MvcModels.Models
{
    public class Book
    {
        public Book()
        {
            Id = -1;
            name = "undefined";
            author = "undefined";
            genre = "undefined";
        }

        public int Id { get; set; }
        public string name { get; set; }
        public string author { get; set; }
        public string genre { get; set; }
    }

    public class BookList : IEnumerable<Book>
    {
        public List<Book> Books { get; set; } = new List<Book>();
        private static BookList instance { get; set; } = null;

        public int size()
        {
            return Books.Count;
        }

        public void add(Book b)
        {
            Books.Add(b);
        }
        public void resetID()
        {
            for(int i = 0; i < size(); i++)
            {
                Books[i].Id = i;
            }
        }
        public bool delete(int id)
        {
            
                Books.RemoveAt(id);
                resetID();
                return true;
            
            //else {
            //    return false;
            //}
        }

        public Book this[int i]
        {
            get { return Books[i]; }
            set { Books[i] = value; }
        }

        public IEnumerator<Book> GetEnumerator()
        {
            return Books.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public static BookList getInstance()
        {
            if (instance == null)
            {
                instance = new BookList();
            }
            return instance;
        }

        public Book find(int id)
        {
            foreach(var bl in Books)
            {
                if (id == bl.Id)
                    return bl;
            }
            return new Book();
        }

        // getting started, constructor generates a list of books
        private BookList()
        {
            var b = new Book
            {
                Id = 1,
                name = "Asp.Net Core 2.0 MVC & Razor Pages",
                author = "Jonas Fagerberg",
                genre = "Technology"
            };
            Books.Add(b);
            var b1 = new Book
            {
                Id = 2,
                name = "C# 7.0 in a Nutshell: The Definitive Reference",
                author = "Joseph Albahari , Ben Albahari",
                genre = "Technology"
            };
            Books.Add(b1);
            var b2 = new Book
            {
                Id = 3,
                name = "Pro ASP.NET Core MVC 2",
                author = "Adam Freeman",
                genre = "Technology"
            };
            Books.Add(b2);
        }
    }
}
