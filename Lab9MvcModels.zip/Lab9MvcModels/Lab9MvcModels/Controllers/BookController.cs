﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Lab9MvcModels.Models;

namespace Lab9MvcModels.Controllers
{
    public class BookController : Controller
    {
        // GET: Book
        public ViewResult Index()
        {
            var model = BookList.getInstance();
            IEnumerable<Book> bList = (IEnumerable<Book>)model.Books;
            return View(bList);
        }

        // GET: Book/Details/5
        public ViewResult Details(int id)
        {
            var model = BookList.getInstance();
            var b = model[id - 1];
            return View(b);
        }

        // GET: Book/Create get form to create a book via id
        public IActionResult Create(int id)
        {
            var bList = BookList.getInstance();
            var model = new Book();
            model.Id = bList.size() + 1;
            return View(model);
        }

        // POST: Book/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(int id, Book b)
        {
            try
            {
                // TODO: Add insert logic here
                var model = BookList.getInstance();
                model.add(b);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Book/Edit/5
        public IActionResult Edit(int id)
        {
            var bList = BookList.getInstance();
            var model = bList[id - 1];
            return View(model);
        }

        // POST: Book/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Book b)
        {
            try
            {
                // TODO: Add update logic here
                var model = BookList.getInstance();
                model[id - 1] = b;
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Book/Delete/5
        public IActionResult Delete(int id)
        {
            var bList = BookList.getInstance();
            if (bList == null)
            {
                return View("NotFound");
            }
            else
            {
                bList.delete(id - 1);
                return RedirectToAction("Index");
            }
        }

        // post: book/delete/5
        //[httppost]
        //[validateantiforgerytoken]
        //public actionresult delete(int id, iformcollection collection)
        //{
        //   try
        //    {
                // todo: add delete logic here

        //        return redirecttoaction(nameof(index));
        //    }
        //    catch
        //    {
        //        return view();
        //    }
        //}
    }
}