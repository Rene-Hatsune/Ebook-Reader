﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace EbookReader.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string name { get; set; }
        public string genre { get; set; }
        public ICollection<Author> Authors { get; set; }
    }

    public class Author
    {
        public int authorID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string isPrimaryAuthor { get; set; }

        public int? BookId { get; set; }
        public Book Book { get; set; }
    }
}
