﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EbookReader.Data
{
    public static class Seed
    {
        public static async Task CreateRoles(IServiceProvider serviceProvider, IConfiguration Configuration)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<IdentityUser>>();
            var signInManager = serviceProvider.GetRequiredService<SignInManager<IdentityUser>>();
            string[] roleNames = { "Administrator", "User" };

            IdentityResult resultRole;

            foreach (var roleName in roleNames)
            {
                var role = await roleManager.RoleExistsAsync(roleName);
                if (!role)
                {
                    resultRole = await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            var powerUser = new IdentityUser
            {
                UserName = Configuration.GetSection("AppSettings")["UserEmail"],
                Email = Configuration.GetSection("AppSettings")["UserEmail"]
            };

            string userPassword = Configuration.GetSection("AppSettings")["UserPassword"];
            var user = await userManager.FindByEmailAsync(Configuration.GetSection("AppSettings")["UserEmail"]);

            if (user == null)
            {
                var createPowerUser = await userManager.CreateAsync(powerUser, userPassword);
                if(createPowerUser.Succeeded)
                {
                    await userManager.AddToRoleAsync(powerUser, "Administrator");
                    await signInManager.SignInAsync(powerUser, isPersistent: false);
                }
            }
            
        }
    }
}
